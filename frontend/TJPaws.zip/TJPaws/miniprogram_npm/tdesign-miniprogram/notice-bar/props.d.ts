import { TdNoticeBarProps } from './type';
declare const props: TdNoticeBarProps;
export default props;
