declare const _default: string;
export default _default;
