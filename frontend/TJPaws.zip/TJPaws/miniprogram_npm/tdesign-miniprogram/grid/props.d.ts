import { TdGridProps } from './type';
declare const props: TdGridProps;
export default props;
