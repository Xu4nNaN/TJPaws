import { show, close, ActionSheetTheme } from './show';
export { ActionSheetTheme };
export default {
    show(options) {
        return show(options);
    },
    close(options) {
        return close(options);
    },
};
