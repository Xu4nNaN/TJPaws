import { TdPickerItemProps } from './type';
declare const props: TdPickerItemProps;
export default props;
