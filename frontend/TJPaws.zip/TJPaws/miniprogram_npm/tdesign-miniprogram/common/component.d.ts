/// <reference types="miniprogram-api-typings" />
declare const TComponent: typeof Component;
export default TComponent;
