:: BASE_DOC ::

## API

### Empty Props

name | type | default | description | required
-- | -- | -- | -- | --
action | Slot | - | \- | N
description | String / Slot | - | \- | N
external-classes | Array | - | `['t-class', 't-class-description', 't-class-image', 't-class-actions']` | N
icon | String | - | \- | N
image | String / Slot | - | \- | N
