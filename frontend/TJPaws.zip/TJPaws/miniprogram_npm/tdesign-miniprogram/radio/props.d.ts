import { TdRadioProps } from './type';
declare const props: TdRadioProps;
export default props;
