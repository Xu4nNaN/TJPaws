Component({
  externalClasses: ['wr-class'],
  properties: {
    knowledgeList: {
      type: Array,
      value: []
    }
  },
  data: {
    // 内部数据
  },
  methods: {
    onClickKnowledge(e) {
      const { index } = e.currentTarget.dataset;
      this.triggerEvent('click', { index });
    }
  }
}); 