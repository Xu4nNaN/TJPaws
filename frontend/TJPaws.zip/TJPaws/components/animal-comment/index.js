Component({
  properties: {
    articleId: String,
    comments: {
      type: Array,
      value: []
    },
    loading: {
      type: Boolean,
      value: false
    },
    hasMore: {
      type: Boolean,
      value: true
    }
  },

  data: {
    content: ''
  },

  methods: {
    onInput(e) {
      this.setData({
        content: e.detail.value
      });
    },

    onSubmit() {
      const { content } = this.data;
      if (!content.trim()) {
        wx.showToast({
          title: '请输入评论内容',
          icon: 'none'
        });
        return;
      }

      this.triggerEvent('submit', { content });
      this.setData({ content: '' });
    },

    onLoadMore() {
      this.triggerEvent('loadmore');
    }
  }
}); 