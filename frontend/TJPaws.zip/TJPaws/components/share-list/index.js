Component({
  externalClasses: ['wr-class'],
  properties: {
    shareList: {
      type: Array,
      value: [],
      observer(newVal) {
        if (newVal && newVal.length > 0) {
          // 处理时间格式化
          const list = newVal.map(item => ({
            ...item,
            createTime: this.formatTime(item.createTime)
          }));
          this.setData({ list });
        }
      }
    }
  },
  data: {
    list: []
  },
  methods: {
    onClickShare(e) {
      const { index } = e.currentTarget.dataset;
      this.triggerEvent('click', { index });
    },
    onLike(e) {
      const { index } = e.currentTarget.dataset;
      this.triggerEvent('like', { index });
      // 阻止事件冒泡
      e.stopPropagation();
    },
    onComment(e) {
      const { index } = e.currentTarget.dataset;
      this.triggerEvent('comment', { index });
      // 阻止事件冒泡
      e.stopPropagation();
    },
    formatTime(timestamp) {
      if (!timestamp) return '';
      
      const now = new Date().getTime();
      const diff = now - timestamp;
      
      // 小于1分钟
      if (diff < 60000) {
        return '刚刚';
      }
      // 小于1小时
      if (diff < 3600000) {
        return `${Math.floor(diff / 60000)}分钟前`;
      }
      // 小于24小时
      if (diff < 86400000) {
        return `${Math.floor(diff / 3600000)}小时前`;
      }
      // 小于30天
      if (diff < 2592000000) {
        return `${Math.floor(diff / 86400000)}天前`;
      }
      
      // 超过30天显示具体日期
      const date = new Date(timestamp);
      return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
    }
  }
}); 