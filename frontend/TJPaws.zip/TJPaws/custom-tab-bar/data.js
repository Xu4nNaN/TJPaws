export default [{
    icon: 'sort',
    text: '首页',
    url: 'pages/home/home',
  },
  // {
  //   icon: 'sort',
  //   text: '帖子',
  //   url: 'pages/goods/category/index',
  // },
  // {
  //   icon: 'sort',
  //   text: '上传',
  //   url: 'pages/cart/index',
  // },
  {
    icon: 'person',
    text: '个人中心',
    url: 'pages/usercenter/index',
  },
];